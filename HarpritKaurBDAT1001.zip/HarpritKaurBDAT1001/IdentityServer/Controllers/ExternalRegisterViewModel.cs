﻿namespace IdentityServer.Controllers
{
    public class ExternalRegisterViewModel
    {
        public string Username { get; set; }
        public string ReturnUrl { get; set; }
    }
}
