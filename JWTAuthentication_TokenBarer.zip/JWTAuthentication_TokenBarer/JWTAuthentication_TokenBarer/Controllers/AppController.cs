﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JWTAuthentication_TokenBarer.Controllers
{
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [ApiController]
    [Route("[controller]")]
    public class AppController : ControllerBase
    {
        private readonly List<app> apps = new List<app>()
        {
            new app { appid = 301, appname = "Gana Music", genre = "media", downloads= 9000000},
            new app { appid = 302,appname = "Beautify", genre = "media", downloads= 300000},
            new app { appid = 303,appname = "Facebook", genre = "communication", downloads= 700000},
            new app { appid = 304,appname = "Sharechat", genre = "media", downloads= 800000},
            new app { appid = 305,appname = "Whatsapp", genre = "communication", downloads= 9000000},

        };
        private readonly ILogger<AppController> _logger;
        public AppController(ILogger<AppController> logger)
        {
            _logger = logger;
        }
        [HttpGet]
        public IEnumerable<app> Get()
        {
            return apps;  
        }
        [HttpGet("{appid:int}")]
        public app GetOne(int appid)
        {
            return apps.SingleOrDefault(x => x.appid == appid );
        }

    }
}